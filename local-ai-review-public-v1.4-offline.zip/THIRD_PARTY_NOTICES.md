# Third-party references and notices

本資料はAngularおよびPythonの技術仕様を参考に独自に整理した非公式のレビュー支援資料です。第三者による承認や保証を意味しません。

## 参考資料（名称のみ）

- Angular Documentation — Version Compatibility, Components, Signals, Security, HTTP, Routing
- Angular framework — MIT License（原著作権表示・再配布条件は該当ライセンスを確認）
- Python 3.13 Documentation — What's New, Library Reference, Language Reference
- Python Software Foundation — PSF License（資料・コード例の条件は別途確認）
- Django Documentation / Django REST Framework Documentation（該当する記述に限る）

## 利用上の注意

本リポジトリの独自の要約とレビュー用ルールは、公式文書の全文転載を目的としません。第三者の文章・コードを新たに転載する場合、権利者の表示やライセンス条件を個別に確認してください。

本ファイルは公開時の権利関係を説明するためのものであり、チャット型Local AIへの添付は不要です。


## v1.3で追加したコード例

追加したコード例は本資料用に独自に作成した架空の短い説明例であり、公式文書・業務コードから転載したものではありません。第三者ライブラリ名・API名は技術的な識別目的で記載しています。独自部分の公開ライセンスについては権利者が決定してください。
