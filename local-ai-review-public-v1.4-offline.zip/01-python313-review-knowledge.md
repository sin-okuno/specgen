# Python 3.13 コードレビュー・ナレッジ v1.4

> **非公式・独立作成のレビュー支援資料です。** Angular、Python、各開発元による承認・保証はありません。仕様の原文ではなく独自の要約とレビュー観点です。対象バージョンと本ファイル内の記載範囲を確認してください。
> **公開版 v1.4**：架空の例のみを使用し、組織固有の情報・実際のGit差分・認証情報は含めません。
> **権利・利用条件**：公開時の第三者権利情報は `THIRD_PARTY_NOTICES.md` に整理しています。Local AIによる参照は不要です。

- 対象: Python 3.13.x（実際のパッチ版・ランタイムを確認）
- 作成日: 2026-10-14
- 用途: `02-review-policy.md` とユーザー取得のGit差分と共にチャット型ローカルAIに添付
- 原則: 本書は公式資料に基づくレビュー用要約。言語仕様と一般的なコード品質推奨を区別する。
- ルール区分: `SPEC`=公式の仕様・互換性、`GUIDE`=一般的なレビュー観点、`PROJECT`=任意のプロジェクト規約。

## A. Python 3.13の重要な変更

### PY313-001 [SPEC] Python 3.13で削除された標準ライブラリ
- 次の19モジュールはPython 3.13の**標準ライブラリから削除**: `aifc`, `audioop`, `cgi`, `cgitb`, `chunk`, `crypt`, `imghdr`, `mailcap`, `msilib`, `nis`, `nntplib`, `ossaudiodev`, `pipes`, `sndhdr`, `spwd`, `sunau`, `telnetlib`, `uu`, `xdrlib`。
- 検出: `import cgi`, `from imghdr import what`, `import telnetlib` など。標準ライブラリだけを前提とする環境ではインポート失敗の可能性が高い。
- 例外: サードパーティーの互換パッケージ等で同名モジュールが提供される可能性があるため、環境を確認する。
- 修正: 使用目的ごとに代替APIを選定。`cgi`のクエリ文字列処理なら `urllib.parse`、MIME解析なら `email` 等を検討。安易な一括置換はしない。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### PY313-002 [SPEC] 追加の削除API
- Python 3.13で `lib2to3` と `2to3`、`tkinter.tix`、`locale.resetlocale()`、`typing.io` / `typing.re` 名前空間などが削除された。
- 検出: これらを直接参照する差分。サードパーティー依存の内部使用は当該パッケージの対応状況を要確認。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### PY313-003 [SPEC] 非推奨と削除を区別
- Python 3.13で非推奨となった機能を「3.13で削除済み」と誤判定しない。
- 例: `http.server.CGIHTTPRequestHandler` は3.13で非推奨。標準ライブラリから削除された `cgi` モジュールとは区別する。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### PY313-004 [SPEC] 新しい型・機能を誤検知しない
- Python 3.13の `typing.ReadOnly`（TypedDict項目）、`typing.TypeIs`、型パラメータのデフォルトなどを、古いモデルの知識だけで構文エラー・未知のAPIと断定しない。
- 対象環境が3.13であることと実際の使用法を確認する。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### PY313-005 [SPEC] 実験的な実行モード
- Python 3.13にはオプションのfree-threadedビルドや実験的JITがある。標準のCPython 3.13が常にGILなしで動くと判断しない。
- 並行実行に関する指摘では実際のビルド・実行設定を確認する。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

## B. 安全性・バグ検出（Python 3.13に限らない一般原則）

### PY313-010 [GUIDE] subprocessとコマンドインジェクション
- `subprocess.run(..., shell=True)` 等に外部入力が渡る経路を確認。`shell=True` だけで脆弱性確定としない。
- 推奨: 可能なら引数リストと `shell=False` を使う。実行対象や引数を検証する。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### PY313-011 [GUIDE] pickleの信頼境界
- 信頼できないデータを `pickle.loads()` / `pickle.load()` で復元すると任意コード実行の危険がある。
- データの出所が不明なら「要確認」。信頼できない入力が確認できれば高重大度で指摘。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### PY313-012 [GUIDE] SQLクエリのパラメータ化
- 外部入力をSQL文に文字列連結・f-stringで埋め込んでいないか確認。DBドライバのプレースホルダを用いる。
- ORMの安全性は実際のAPIと使い方による。生SQLの使用だけで脆弱性確定としない。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### PY313-013 [GUIDE] 例外処理とリソース解放
- `except Exception: pass`、過度に広い例外捕捉、失敗を成功扱いする処理を確認。
- ファイル・接続・ロックの解放を確認。`with` / `try-finally` 等を状況に応じて提案。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### PY313-014 [GUIDE] 非同期処理
- `async def` 内でのブロッキングI/O、await漏れ、Taskの例外伝播、キャンセル処理を確認。
- `asyncio.create_task()` の呼び出しを無条件に禁止しない。Taskの寿命と参照保持を検討する。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### PY313-015 [GUIDE] 可変デフォルト引数
- `def f(items=[])` のような可変デフォルト値は呼び出し間で共有される。意図しない状態共有を確認する。
- 共有を意図している場合はバグと断定しない。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### PY313-016 [GUIDE] 型ヒントと実行時検査の違い
- 型ヒントは原則としてランタイムの入力バリデーションを自動実施しない。`Optional` や `TypedDict` 等の注釈だけで入力安全性が保証されると判断しない。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

## C. Web API・Django利用時の注意（条件付き）

### PY313-P01 [PROJECT] Django/DRFの互換性
- Python 3.13対応状況は採用Django・DRFバージョンごとに確認。Python 3.13だからすべてのDjango/DRFが対応するとは断定しない。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### PY313-P02 [PROJECT] 認証・認可
- APIの認証、オブジェクト単位権限、CSRF、ユーザー所有データへのアクセス制限を、差分に関連する場合のみ確認する。
- Session認証とJWT認証は方式が異なる。`SessionAuthentication` のCSRF要件をJWT全般へ誤って適用しない。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### PY313-P03 [PROJECT] Serializer / View / Service
- 分離ルールはプロジェクトで定めた場合のみ適用。Django/DRF公式の必須構成であるかのように断定しない。

## D. 差分レビュー時の重点事項

1. 変更コードに削除済み標準ライブラリへの参照があるか。
2. 追加した依存ライブラリがPython 3.13に対応しているか（依存関係の証拠が必要）。
3. 外部入力からSQL・シェル・デシリアライズへの経路があるか。
4. 例外処理、リソース管理、async処理の欠陥が変更によって生じるか。
5. 関連コードが見えない場合は「要確認」とし、確認対象を具体的に示す。

## E. 禁止事項

- Python 3.13に存在する新機能を古い知識だけでエラー扱いしない。
- 削除済みと非推奨を混同しない。
- 公式ドキュメントを閲覧していないチャットAIは閲覧済みと主張しない。
- Ruff/mypy/pytestを実行していないのに「検証済み」と言わない。
- 差分にない依存関係や権限処理を推測で断定しない。

## F. オフライン参照方針

- 本ファイルのルール本文とRule IDを判断根拠とする。
- 外部サイトの検索・閲覧を要求しない。
- 記載のない仕様は「要確認」とし、推測で断定しない。


> 注意: 本書はPython 3.13の全変更点を網羅しない。特に依存ライブラリの対応状況とランタイム設定は別途確認する。


---

# I. 実装パターン集（追加 v1.4）

以下は本資料用に独自作成した架空のコード。`NG` は条件付きの問題例、`OK` は当該論点に限る改善例。コード例の再現性はプロジェクト構成・依存ライブラリによって異なる。外部URLの参照は不要。

### PY313-050 [SPEC] 削除済み標準ライブラリを直接importしない
- 検査: Python 3.13で `cgi` / `imghdr` 等を標準ライブラリとして利用していないか。
- 例外: 明示的な互換パッケージが提供される環境では確認が必要。

```python
# NG (3.13標準ライブラリのみ): import cgi
# OK: クエリ文字列を解析する用途に限定した代替
from urllib.parse import parse_qs
params = parse_qs('name=demo&name=test')
# {'name': ['demo', 'test']}
```

### PY313-051 [SPEC] 3.13で有効な型APIを誤検知しない
- 検査: `typing.ReadOnly` と `typing.TypeIs` を存在しないAPIとして扱わない。
- 例外: 静的型検査器や依存ライブラリの対応状況は別途確認。

```python
from typing import ReadOnly, TypedDict, TypeIs

class UserRecord(TypedDict):
    id: ReadOnly[int]
    name: str

def is_string(value: object) -> TypeIs[str]:
    return isinstance(value, str)
```

### PY313-052 [GUIDE] 外部入力をシェル文字列に埋め込まない
- 検査: `shell=True` と未検証の外部入力が結合する場合。
- 例外: 固定文字列を使う意図的なシェル処理は一律に脆弱性としない。

```python
import subprocess
# NG: 外部入力をシェルに解釈させる
# subprocess.run(f'echo {user_input}', shell=True, check=True)
# OK: シェルを介さず引数を分離
subprocess.run(['echo', user_input], check=True)
```

### PY313-053 [GUIDE] SQLは値をパラメータとして渡す
- 検査: SQL文へユーザー入力をf-string等で埋め込んでいないか。
- 例外: テーブル名・列名は値のプレースホルダでは置換できないため、許可リスト等で検証。

```python
import sqlite3
conn = sqlite3.connect(':memory:')
conn.execute('CREATE TABLE items (name TEXT)')
name = 'example'
# NG: conn.execute(f"SELECT * FROM items WHERE name = '{name}'")
# OK: DBドライバのプレースホルダを利用
rows = conn.execute('SELECT * FROM items WHERE name = ?', (name,)).fetchall()
```

### PY313-054 [GUIDE] `pickle` は信頼できない入力に使用しない
- 検査: リクエスト、アップロード、外部ストレージ由来のバイト列を `pickle.loads` に渡す場合。
- 例外: 信頼できる内部データでも改ざん可能性・完全性を評価する。

```python
import json
# NG: value = pickle.loads(untrusted_bytes)
# OK: JSONを受け取り、さらにスキーマ検証する
value = json.loads(untrusted_bytes.decode('utf-8'))
if not isinstance(value, dict):
    raise ValueError('object required')
```

### PY313-055 [GUIDE] 可変デフォルト引数の共有状態
- 検査: 関数呼び出し間でリストや辞書が意図せず共有されないか。
- 例外: キャッシュ等で共有が意図された場合は要件を確認。

```python
# NG: def append_item(value, items=[]): ...
def append_item(value: int, items: list[int] | None = None) -> list[int]:
    if items is None:
        items = []
    items.append(value)
    return items
```

### PY313-056 [GUIDE] `async def` 内の同期ブロッキング処理
- 検査: 非同期Web処理で `time.sleep` や同期ネットワークI/Oがイベントループを停止させないか。
- 例外: 専用スレッドに移譲している場合や同期関数の文脈は別。

```python
import asyncio
async def poll() -> None:
    # NG: time.sleep(1)
    await asyncio.sleep(1)  # OK: 他タスクに実行機会を渡す
```

### PY313-057 [GUIDE] `asyncio` タスクのキャンセルを飲み込まない
- 検査: キャンセルを意図せず握りつぶす、Taskの例外を未回収のまま放置する。
- 誤検知防止: `asyncio.CancelledError` の継承関係と例外捕捉範囲を考慮する。

```python
import asyncio
async def worker() -> None:
    try:
        await asyncio.sleep(10)
    except asyncio.CancelledError:
        # 後始末が必要ならここで行い、キャンセルを伝播
        raise
```

### PY313-058 [GUIDE] ファイル・トランザクションを確実に閉じる
- 検査: 例外時にファイルや接続が開いたままになるか。
- 例外: 所有権を別コンポーネントに委譲している場合は契約を確認。

```python
from pathlib import Path
# OK: コンテキストマネージャでファイルを閉じる
with Path('example.txt').open(encoding='utf-8') as stream:
    content = stream.read()
```

### PY313-059 [GUIDE] Django ORMで所有者を絞る（任意のWebアプリ例）
- 検査: 他ユーザーのレコードIDを指定するだけで参照・更新できないか。
- 例外: 管理者権限などの例外要件がある場合は権限設計を確認。

```python
# Django ORMの概念例。modelと認証設定は省略。
# NG: obj = get_object_or_404(Item, pk=item_id)  # 権限チェックが他にない場合
# OK: 認証済みrequest.userが所有するデータに限定
obj = get_object_or_404(Item, pk=item_id, owner=request.user)
```

### PY313-060 [GUIDE] DRFの権限を表示制御だけに任せない
- 検査: APIの認証・権限設定、オブジェクト単位の認可が差分で確認できるか。
- 例外: 別クラスや共通基底クラスで実施している場合がある。差分に無ければ要確認。

```python
# DRFの概念例（必要なimports・モデルは省略）
class ItemViewSet(ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = ItemSerializer

    def get_queryset(self):
        return Item.objects.filter(owner=self.request.user)
# 注意: 作成時のowner設定・管理者例外・操作別権限は別途設計が必要
```

### PY313-061 [GUIDE] パスの結合とディレクトリ逸脱
- 検査: リクエストのファイル名を使い、許可ディレクトリの外を読み書きできないか。
- 例外: 外部入力の有無、シンボリックリンク、実際のファイル権限を確認。

```python
from pathlib import Path
base = Path('/srv/app/uploads').resolve()
requested = 'report.txt'  # 実際は入力検証が必要
candidate = (base / requested).resolve()
if not candidate.is_relative_to(base):
    raise ValueError('invalid path')
# 注意: シンボリックリンクの競合やTOCTOU対策は要件次第で追加する
```

### PY313-062 [GUIDE] 認証情報をログに出さない
- 検査: パスワード、Bearerトークン、Cookie、秘密鍵、個人情報が例外ログやデバッグログに出ていないか。
- 例外: ダミー値・マスク済みログを本物の漏洩と混同しない。

```python
# NG: logger.info('Authorization=%s', request.headers.get('Authorization'))
# OK: 秘密情報を含めずイベントを記録
logger.info('authentication failed')
```

## J. 追加チェックリスト（Python 3.13の言語仕様と混同しない）

| ID | 分野 | 確認事項 | 注意 |
|---|---|---|---|
| PY313-063 [GUIDE] | 型 | `TypedDict` / `TypeIs` / `ReadOnly` の意図と型検査結果 | 型ヒントは実行時バリデーションではない |
| PY313-064 [GUIDE] | 日時 | aware/naive datetimeの混在、タイムゾーン境界 | UTC固定が常に業務要件に合うとは限らない |
| PY313-065 [GUIDE] | 数値 | 浮動小数点を金額計算に利用する必要性 | 必要なら`decimal.Decimal`を検討 |
| PY313-066 [GUIDE] | HTTP | timeout、リトライ、冪等性、例外伝播 | 外部I/Oが見えないなら断定しない |
| PY313-067 [GUIDE] | JSON | 入力サイズ、型、必須キー、想定外のネスト | JSON採用だけで安全とは言わない |
| PY313-068 [GUIDE] | 正規表現 | 外部入力で計算量が急増するパターン | 実際の入力経路を確認 |
| PY313-069 [GUIDE] | 並行処理 | 共有状態、ロック、スレッド安全性 | free-threadedビルドを既定とみなさない |
| PY313-070 [GUIDE] | テスト | エラー・境界・認可・並行性の回帰テスト | テスト不在だけで実装バグ確定としない |
| PY313-071 [GUIDE] | 依存 | Django/DRF/ドライバの3.13対応 | 具体的な導入版の情報が必要 |
| PY313-072 [GUIDE] | 例外 | `except Exception` で失敗を成功扱いしていないか | 意図的なフォールバックは許容 |

## K. レビュー結果に記す証拠

- 差分の該当行、外部入力の到達経路、発生条件、対象バージョンを確認する。
- `SPEC` は対象ランタイムの事実、`GUIDE` は条件付き推奨、`PROJECT` は採用時のみ適用する。
- この資料のサンプルコードは**Git差分の事実の代わりにならない**。
- Django/DRFのコード例はPython 3.13の標準機能ではなく、依存ライブラリの仕様・設定が別途必要。


---

# L. 優先追加ルール：非同期・入力境界・認可・データ整合性

以下は実務上の欠落を補う追加ルール。`SPEC`は対象仕様の確認を要するもの、`GUIDE`は一般的な安全・品質上の検査観点。例はすべて架空で、概念を示す断片であり、単体で実行できる完全な実装ではない。URLアクセスを要求しない。

### PY313-080 [SPEC] 3.13削除モジュールのimport
- **検出条件**: cgi、cgitb、imghdr、telnetlib、pipesなど3.13で削除された標準モジュールを直接importしていないか。
- **誤検知回避**: サードパーティの同名パッケージや独自互換レイヤーの存在は別途確認。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
import imghdr
```
**改善例（条件付き）**
```python
# 目的に応じてファイル署名検査用の保守されたライブラリを選ぶ
```

### PY313-081 [GUIDE] 型ヒントと実行時検証の混同
- **検出条件**: 型注釈だけで外部入力が検証されたとみなしていないか。
- **誤検知回避**: 別レイヤーで検証済みなら指摘しない。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
def save(age: int): return age + 1 # JSON値の型は未検証
```
**改善例（条件付き）**
```python
def save(age: object):
    if not isinstance(age, int) or isinstance(age, bool): raise ValueError('age')
    return age + 1
```

### PY313-082 [GUIDE] async内のブロッキング処理
- **検出条件**: async def内部で重い同期I/Oを実行しイベントループを止めていないか。
- **誤検知回避**: 短い処理や専用ワーカー上の実行なら影響を評価。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
async def fetch(): return requests.get(endpoint, timeout=3).text
```
**改善例（条件付き）**
```python
async def fetch(client): return (await client.get('/items')).text
```

### PY313-083 [GUIDE] TaskGroupでの例外伝播
- **検出条件**: 子タスクの失敗・キャンセルを無視して処理成功と扱っていないか。
- **誤検知回避**: 意図した部分成功の仕様がある場合は別設計を確認。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
async with asyncio.TaskGroup() as tg: tg.create_task(job()) # 例外の扱いが未設計
```
**改善例（条件付き）**
```python
try:
    async with asyncio.TaskGroup() as tg: tg.create_task(job())
except* ValueError as group:
    handle_errors(group)
```

### PY313-084 [GUIDE] CancelledErrorの伝播
- **検出条件**: キャンセルを捕捉して握りつぶし、タスク停止要求が機能しないか。
- **誤検知回避**: 意図した後始末をしたうえで再送出していれば問題なし。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
except asyncio.CancelledError: return None
```
**改善例（条件付き）**
```python
except asyncio.CancelledError:
    await cleanup()
    raise
```

### PY313-085 [GUIDE] SQLパラメータ化
- **検出条件**: 外部入力をSQL文字列へ直接埋め込んでいないか。
- **誤検知回避**: プレースホルダーの記法はDBドライバごとに確認。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
cursor.execute(f'SELECT * FROM items WHERE id={item_id}')
```
**改善例（条件付き）**
```python
cursor.execute('SELECT * FROM items WHERE id = %s', (item_id,)) # ドライバ依存
```

### PY313-086 [GUIDE] subprocessのコマンド組立
- **検出条件**: 未検証入力をshell=Trueでコマンド文字列に連結していないか。
- **誤検知回避**: shell=True自体を一律脆弱性とはせず入力経路を確認。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
subprocess.run('convert ' + filename, shell=True)
```
**改善例（条件付き）**
```python
subprocess.run(['convert', filename], check=True) # 許可コマンド・パスを別途検証
```

### PY313-087 [GUIDE] pickleの信頼境界
- **検出条件**: 外部から届くpickleデータを復元していないか。
- **誤検知回避**: 信頼された内部データに限定されているなら条件を確認。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
obj = pickle.loads(request_body)
```
**改善例（条件付き）**
```python
obj = json.loads(request_body) # さらにスキーマ検証が必要
```

### PY313-088 [GUIDE] パス検証とTOCTOU
- **検出条件**: 検証後に別パスへ差し替え可能な環境でファイル操作していないか。
- **誤検知回避**: 攻撃者がディレクトリを変更できない場合はリスクが異なる。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
if path.resolve().is_relative_to(base): return path.read_text()
```
**改善例（条件付き）**
```python
# 権限・ディレクトリ所有者・シンボリックリンク競合まで含め設計
```

### PY313-089 [GUIDE] ログに秘密情報を出さない
- **検出条件**: Authorization、Cookie、秘密鍵、パスワード、個人情報を記録していないか。
- **誤検知回避**: 伏せ字・ダミー文字列は誤検知しない。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
logger.debug('headers=%s', request.headers)
```
**改善例（条件付き）**
```python
logger.info('request rejected', extra={'status': 401})
```

### PY313-090 [GUIDE] DRFのget_querysetによる所有者制限
- **検出条件**: 一覧・詳細・更新の取得対象が適切に認可されるか。
- **誤検知回避**: 管理者例外や共通Permissionが別にあれば確認。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
queryset = Item.objects.all() # 所有者限定要件なら危険
```
**改善例（条件付き）**
```python
def get_queryset(self): return Item.objects.filter(owner=self.request.user)
```

### PY313-091 [GUIDE] DRF作成時のowner偽装
- **検出条件**: リクエストから渡されたownerを無検証で保存していないか。
- **誤検知回避**: 管理者が代理登録できる仕様なら条件を明記。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
serializer.save(owner_id=request.data['owner_id'])
```
**改善例（条件付き）**
```python
serializer.save(owner=request.user) # 認証・権限が前提
```

### PY313-092 [GUIDE] Django ORMのN+1
- **検出条件**: 一覧表示で各行の関連オブジェクトへ個別アクセスしていないか。
- **誤検知回避**: 行数が少ない場合は実測で優先度を判断。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
items = Item.objects.all(); names = [x.owner.name for x in items]
```
**改善例（条件付き）**
```python
items = Item.objects.select_related('owner'); names = [x.owner.name for x in items]
```

### PY313-093 [GUIDE] トランザクションと競合更新
- **検出条件**: 複数テーブル更新の途中失敗や競合で不整合が生じないか。
- **誤検知回避**: 単一SQLで原子的に完結する場合は不要なロックを要求しない。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
balance = account.balance; account.balance = balance - amount; account.save()
```
**改善例（条件付き）**
```python
Account.objects.filter(pk=account.pk).update(balance=F('balance') - amount) # 残高下限は別途保証
```

### PY313-094 [GUIDE] HTTPクライアントのタイムアウト
- **検出条件**: 外部通信が無期限に待機しないか。
- **誤検知回避**: SDK既定のtimeoutが確認できれば問題なし。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
requests.get(endpoint)
```
**改善例（条件付き）**
```python
requests.get(endpoint, timeout=(3, 10))
```

### PY313-095 [GUIDE] リトライと冪等性
- **検出条件**: 副作用のあるPOSTを無条件に再送して重複登録しないか。
- **誤検知回避**: 冪等キー・サーバー側の重複排除があれば許容。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
for _ in range(3): post_order(payload)
```
**改善例（条件付き）**
```python
# 注文作成は冪等キー等の契約がある場合のみ自動再試行
```

### PY313-096 [GUIDE] 日時のaware/naive混在
- **検出条件**: UTCとローカル時刻の比較・保存でずれが発生しないか。
- **誤検知回避**: アプリ全体が明確な単一タイムゾーン仕様なら条件を確認。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
datetime.now() > stored_utc
```
**改善例（条件付き）**
```python
datetime.now(timezone.utc) > stored_utc # stored_utcもawareが前提
```

### PY313-097 [GUIDE] 例外の握りつぶし
- **検出条件**: except Exceptionで失敗を成功として返さないか。
- **誤検知回避**: 意図したフォールバックや監視がある場合は例外。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
try: save()
except Exception: pass
```
**改善例（条件付き）**
```python
try: save()
except DatabaseError:
    logger.exception('save failed')
    raise
```

### PY313-098 [GUIDE] JSON入力の境界値
- **検出条件**: 外部JSONのサイズ・型・必須フィールド・ネストを検証するか。
- **誤検知回避**: フレームワーク側で上限と検証が適用済みなら除外。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
data = json.loads(body); process(data['items'])
```
**改善例（条件付き）**
```python
data = json.loads(body); validate_schema(data); process(data['items'])
```

### PY313-099 [GUIDE] テストの境界・権限・異常系
- **検出条件**: 変更された条件分岐について正常系だけでなく認可・空値・例外・競合を検証したか。
- **誤検知回避**: テストが差分外に存在する可能性を考慮する。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```python
def test_list(): assert get_items()
```
**改善例（条件付き）**
```python
def test_list_denied(): assert client.get('/items/other').status_code in (403, 404)
```

