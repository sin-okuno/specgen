# Angular 22 コードレビュー・ナレッジ v1.4

> **非公式・独立作成のレビュー支援資料です。** Angular、Python、各開発元による承認・保証はありません。仕様の原文ではなく独自の要約とレビュー観点です。対象バージョンと本ファイル内の記載範囲を確認してください。
> **公開版 v1.4**：架空の例のみを使用し、組織固有の情報・実際のGit差分・認証情報は含めません。
> **権利・利用条件**：公開時の第三者権利情報は `THIRD_PARTY_NOTICES.md` に整理しています。Local AIによる参照は不要です。

- 対象: Angular 22.0.x（マイナーバージョンはプロジェクトで確認）
- 作成日: 2026-10-14
- 用途: チャット型ローカルAIに `02-review-policy.md` とユーザー取得の Git diff と共に添付
- 原則: **本書は公式ドキュメントの全文ではなく、レビュー用に整理した要約と検査ルール**。記載のないAPIを「存在しない」「非推奨」と断定しない。
- ルールの強さ: `SPEC`=公式仕様に基づく互換性・安全上の判断、`GUIDE`=公式推奨に基づく注意、`PROJECT`=採用する場合のみ適用するプロジェクト規約。

## A. 互換性と適用範囲

### NG22-001 [SPEC] 依存バージョンの整合性
- Angular **22.0.x**: Node.js `^22.22.3 || ^24.15.0 || ^26.0.0`、TypeScript `>=6.0.0 <6.1.0`、RxJS `^6.5.3 || ^7.4.0`。
- 検査: `package.json`、lockfile、実際の実行環境が提示された場合のみ照合。`package.json` の範囲指定だけで実インストール版を断定しない。
- 指摘: 明確に不整合が確認できれば High、情報不足なら要確認。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### NG22-002 [GUIDE] バージョン固有仕様の確認
- 本資料の記述がAngular 22の対象マイナーバージョンに適合するか、添付された設定と照合する。
- Angularの新機能・古い構文・推奨スタイルの差を「コンパイル不可」と混同しない。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

## B. コンポーネントとテンプレート

### NG22-010 [GUIDE] NgModuleを誤検知しない
- NgModule構成の既存アプリを、Standaloneではないという理由だけでバグ扱いしない。
- 新規コンポーネントの `standalone` のデフォルト挙動と、既存NgModule宣言との整合性を確認する。対象コードと設定が見えなければ要確認。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### NG22-011 [SPEC] テンプレートでの信頼できない値の扱い
- テンプレートでの通常のバインディングと、DOM APIによる直接操作、`innerHTML`、`DomSanitizer.bypassSecurityTrust*` はリスクが異なる。
- `bypassSecurityTrust*` にユーザー入力など未検証の値が到達する場合、入力源と信頼境界を調査し、XSSの可能性を指摘する。
- `innerHTML` の使用だけでXSS確定としない（Angularのサニタイズ処理を考慮）。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### NG22-012 [GUIDE] テンプレートの制御フロー
- `@if`、`@for`、`@switch` はAngularのテンプレート制御フロー構文。古いモデルが未知の構文として誤検知してはいけない。
- `@for` の追跡キーがデータ更新時に適切か確認する。性能問題は実際の更新パターンを考慮して指摘。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

## C. Signals / リアクティビティ

### NG22-020 [SPEC] Signalの読み取りと更新
- Signalは `count()` のように呼び出して値を読む。書き込み可能Signalは `set()` / `update()` で変更する。
- `computed()` は派生値を表す。変更可能な状態を不適切に `computed` に代入しようとしていないか確認する。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### NG22-021 [GUIDE] effectと状態伝播
- `effect()` を無条件に禁止しない。外部システム同期など適切な用途がある。
- 派生状態をeffectで連鎖的に更新している場合は、循環更新・不要な実行・保守性を検討し、`computed()` などの代替を条件付きで提案。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

## D. DI / HTTP / 非同期処理

### NG22-030 [GUIDE] 依存性注入
- `inject()` とコンストラクタDIの両方を正当な選択肢として扱う。`inject()` の呼び出し位置が注入コンテキストか確認する。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### NG22-031 [GUIDE] HttpClientとエラー処理
- API通信の成功・失敗・キャンセルの扱いを確認。HTTP 403を権限不足として扱う場合、401との区別と画面表示を確認。
- HTTPリクエストの `Observable` は購読・Signal変換などの利用形態を確認。購読していないだけで「必ずバグ」と断定しない。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### NG22-032 [GUIDE] RxJS購読のライフサイクル
- 長寿命ストリームの購読解除、`async` パイプ、`takeUntilDestroyed()` などを確認する。
- 完了するHTTPストリームへの一回の購読を、無条件にメモリリークと判定しない。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

## E. セキュリティ

### NG22-040 [SPEC] クライアント側権限判定の限界
- AngularのGuard・画面非表示はUXの補助であり、サーバー側の認証・認可の代替ではない。
- 差分からAPI権限欠落を断定するにはバックエンドの情報が必要。未提示なら要確認。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### NG22-041 [GUIDE] URL・DOM・HTMLの信頼境界
- 外部から与えられたURL、動的HTML、DOM直接操作、危険な信頼バイパスを確認。入力元が不明な場合はリスク条件を明示する。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

## F. プロジェクト固有の任意ルール（公式Angular仕様ではない）

### NG22-P01 [PROJECT] NgRxを採用している場合（任意）
- Action→Effect→API Service→Reducer/Store の責務分離を確認。`dispatch: false` は副作用専用Effectなどで正当な場合がある。
- Store/Effectの構成はプロジェクトの採用規約に従い、異なる構成を即座にバグ扱いしない。
- 根拠: 本項のルールID・検出条件・例外条件（外部アクセス不要）

### NG22-P02 [PROJECT] 既存NgModuleアプリの場合（任意）
- NgModuleベースを維持するというプロジェクト規約がある場合、Standalone移行をレビューの必須修正にしない。

### NG22-P03 [PROJECT] API層の分離（任意）
- `HttpClient` をServiceに集約するなどのプロジェクト規約が明示されている場合にのみ、層違反を指摘する。

## G. 判定上の禁止事項

1. 新しいAPIを学習していないという理由で「存在しない」と判断しない。
2. 非推奨・削除済み・非推奨ではないが別の推奨方式がある、を区別する。
3. `@if` / `@for` / Signals / `inject()` / NgModule / NgRx Effect を無条件に問題視しない。
4. 差分外のバックエンド権限、Interceptor、Guardの存在・不在を推測しない。
5. 外部サイトを参照したと主張しない。根拠は本書のルールIDと、diff内の該当コードのみを示す。

## H. オフライン参照方針


> 注意: 本書はAngular 22全APIの網羅資料ではない。マイナーバージョン差、NgRx・TypeScript・RxJSの詳細は採用バージョンを確認する。


---

# I. 実装パターン集（追加 v1.4）

この章のコードは本資料用に独自作成した架空の最小例。`NG` は**条件が成立した場合の問題例**、`OK` は説明対象の論点に関する改善例であり、周辺実装の安全性を保証しない。import、宣言、テンプレート等は読みやすさのため省略することがある。`SPEC` と `GUIDE` と `PROJECT` の区分を維持する。

### NG22-050 [SPEC] `@for` の `track` は項目の同一性に対応させる
- 検査: 並び替え・挿入・削除があるリストで `$index` を追跡キーにすると、DOM状態が別項目に紐づくリスクがある。
- 例外: 順序も内容も変わらない静的リストでは `$index` が妥当な場合がある。

```html
<!-- NG: 並べ替え可能な一覧で位置をキーにする -->
@for (item of items(); track $index) {
  <app-item-editor [item]="item" />
}

<!-- OK: 安定した一意IDを使用 -->
@for (item of items(); track item.id) {
  <app-item-editor [item]="item" />
}
```

### NG22-051 [SPEC] `computed` は読み取り専用の派生値
- 検査: `computed` の結果に `set` / `update` を呼ぼうとする変更は型・API不整合。
- 誤検知防止: `computed(() => ...)` 自体は有効。`signal` の直接更新も有効。

```ts
import { computed, signal } from '@angular/core';
const price = signal(100);
const taxIncluded = computed(() => Math.round(price() * 1.1));
// NG: taxIncluded.set(200); // computedにはsetがない
price.set(200); // OK: 元の書き込み可能Signalを更新
```

### NG22-052 [GUIDE] `effect` 内の状態更新は目的と循環依存を確認
- 検査: 派生値のためだけにeffectで別Signalを更新している場合、再実行・状態不整合を検討。
- 例外: ロギング、外部API連携、非リアクティブシステムへの同期などは正当な用途がある。

```ts
import { computed, signal } from '@angular/core';
const first = signal('Ada');
const last = signal('Lovelace');
// OK: 値の派生はcomputedで表現
const fullName = computed(() => `${first()} ${last()}`);
```

### NG22-053 [SPEC] `inject()` の実行コンテキスト
- 検査: ボタン操作などの通常のメソッド実行時に `inject()` を新規呼び出ししていないか。
- 例外: フィールド初期化子・コンストラクタ・DIコンテキストで実行する関数等は有効。

```ts
import { Component, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({ selector: 'app-example', template: '<button (click)="load()">Load</button>' })
export class ExampleComponent {
  private readonly http = inject(HttpClient); // OK: フィールド初期化
  load(): void {
    // NG: const http = inject(HttpClient); // 通常のクリックハンドラはDIコンテキスト外
    this.http.get('/api/items').subscribe();
  }
}
```

### NG22-054 [GUIDE] RxJSの購読解除とHTTP完了を区別
- 検査: `interval`、イベント、長寿命Subjectなどがコンポーネント破棄後も購読されないか。
- 例外: 通常のHttpClientリクエストは完了する。購読があるだけでリークとは判定しない。

```ts
import { Component, DestroyRef, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { interval } from 'rxjs';
@Component({ selector: 'app-clock', template: '' })
export class ClockComponent {
  private readonly destroyRef = inject(DestroyRef);
  start(): void {
    interval(1000)
      .pipe(takeUntilDestroyed(this.destroyRef)) // OK: メソッド内では明示的にDestroyRefを渡す
      .subscribe(() => { /* UI更新等 */ });
  }
}
```

### NG22-055 [SPEC] AngularのHTMLサニタイズを迂回しない
- 検査: 外部入力が `bypassSecurityTrustHtml` 等に到達する経路。
- 誤検知防止: 通常の `[innerHTML]` はAngularのサニタイズ対象であり、それだけでXSS成立とは断定しない。

```ts
// NG: 外部入力を検証せず信頼済みHTMLとして扱う
// const html = sanitizer.bypassSecurityTrustHtml(userSuppliedHtml);
// OK: 通常のバインディングを使いAngularのサニタイズに任せる
// template: `<div [innerHTML]="userSuppliedHtml"></div>`
// 注意: サニタイズで許容される表現と要件の整合は別途確認する
```

### NG22-056 [GUIDE] リクエスト競合による古い検索結果の上書き
- 検査: 入力変更ごとに独立subscribeすると遅い応答が新しい結果を上書きする場合がある。
- 例外: 並行リクエストが必要な要件では `switchMap` は不適切な場合がある。

```ts
import { FormControl } from '@angular/forms';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs';
const search = new FormControl('', { nonNullable: true });
// API service の searchItems は Observable を返す想定
const results$ = search.valueChanges.pipe(
  debounceTime(250),
  distinctUntilChanged(),
  switchMap(term => apiService.searchItems(term)) // OK: 旧検索を切り替える
);
```

### NG22-057 [SPEC] フォームの入力値はクライアント側で検証しても信用しない
- 検査: Angularフォームの `Validators.required` 等だけでAPI側の検証・認可が不要とする設計。
- 例外: API側実装が差分に無い場合、欠落を断定せず「要確認」。

```ts
// フロントエンドのバリデーションはUX向上用
// サーバーは入力形式・所有者・権限を別途検証する必要がある
```

### NG22-058 [GUIDE] `HttpClient` のエラー分岐とユーザー表示
- 検査: 401（認証状態の問題）と403（認可拒否）を同一処理にまとめて誤誘導していないか。
- 例外: アプリ固有の認証方式やAPI仕様がある場合はそれを優先。

```ts
import { HttpErrorResponse } from '@angular/common/http';
function messageFor(error: HttpErrorResponse): string {
  if (error.status === 401) return '認証状態を確認してください';
  if (error.status === 403) return 'この操作を実行する権限がありません';
  return '処理に失敗しました';
}
```

### NG22-059 [PROJECT] NgRx Effect の `dispatch: false` を誤検知しない
- 検査: 成功Actionを受けて画面遷移するだけのEffectは新しいActionを発行しなくてもよい。
- 例外: 新たなActionを発行すべき処理に `dispatch: false` が付いている場合は要確認。

```ts
// OK: 副作用専用Effectの概念例（必要なimportsは省略）
readonly navigateAfterSave$ = createEffect(
  () => this.actions$.pipe(
    ofType(saveSuccess),
    tap(({ id }) => { void this.router.navigate(['/items', id]); })
  ),
  { dispatch: false }
);
```

### NG22-060 [GUIDE] 非同期結果の空値・例外とテンプレート
- 検査: 非同期データが未取得の時点で `user.name` を参照していないか。
- 誤検知防止: `@if (user(); as u)` やオプショナルチェーンを用いた安全な分岐は有効。

```html
@if (user(); as u) {
  <span>{{ u.name }}</span>
} @else {
  <span>読み込み中</span>
}
```

## J. 追加チェックリスト（証拠がある場合のみ指摘）

| ID | 分野 | 確認事項 | 誤検知防止 |
|---|---|---|---|
| NG22-061 [GUIDE] | Change detection | 状態の更新が画面に反映されるか | OnPush使用だけで不具合としない |
| NG22-062 [GUIDE] | Template | `@if` / `@for` 分岐にnull・空配列の想定があるか | 新構文を未対応と扱わない |
| NG22-063 [GUIDE] | Forms | `patchValue`、disabled、非同期検証の意図が一致するか | UI要件未提示なら断定しない |
| NG22-064 [GUIDE] | Routing | GuardでUXを制御し、API側認可を別途確認するか | GuardだけでAPIの脆弱性確定としない |
| NG22-065 [GUIDE] | Interceptor | エラー処理や認証ヘッダの重複・無限再試行がないか | Interceptorの存在を推測しない |
| NG22-066 [GUIDE] | Async | `switchMap` / `concatMap` / `exhaustMap` の競合方針が要件と一致するか | 演算子の選択を一律に強制しない |
| NG22-067 [GUIDE] | Security | トークンや機密値をログ・URL・画面に出していないか | トークン保存方式の優劣を無条件に断定しない |
| NG22-068 [GUIDE] | Rendering | 大量リストで追跡キー・再描画・仮想化の必要性を検討したか | 性能測定がない場合は推奨止まり |
| NG22-069 [PROJECT] | Architecture | NgModule、NgRx、Service層の採用規約に沿っているか | 規約が添付されていない場合は適用しない |
| NG22-070 [GUIDE] | Accessibility | ボタン操作、ラベル、キーボード操作を損なっていないか | 要件・対象UIを確認 |

## K. レビュー結果に記す証拠

1. **実際の差分の行**と**発生条件**を記載する。コード例が似ているだけで断定しない。
2. Rule IDを記載し、SPEC/GUIDE/PROJECTを併記する。
3. サンプルコードの `NG` コメントは**教育用の印**であり、対象差分に同じ問題がある証拠ではない。
4. バージョン固有の断定は、依存バージョン・ビルド設定の確認ができた場合に限る。


---

# L. 優先追加ルール：競合・状態管理・セキュリティ・フォーム・NgRx

以下は実務上の欠落を補う追加ルール。`SPEC`は対象仕様の確認を要するもの、`GUIDE`は一般的な安全・品質上の検査観点。例はすべて架空で、概念を示す断片であり、単体で実行できる完全な実装ではない。URLアクセスを要求しない。

### NG22-080 [SPEC] @for の track キー重複
- **検出条件**: 同じ繰り返し内でtrack式が重複し、要素の識別が不安定になるか。
- **誤検知回避**: IDが一意で安定していれば問題なし。index追跡は静的な配列などでは許容。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
@for (item of items(); track item.category) { <li>{{ item.name }}</li> }
```
**改善例（条件付き）**
```typescript
@for (item of items(); track item.id) { <li>{{ item.name }}</li> }
```

### NG22-081 [GUIDE] 非同期検索の古い応答による上書き
- **検出条件**: 検索条件変更後、先行要求の遅い応答が新しい結果を上書きするか。
- **誤検知回避**: 全件を保存する仕様や、要求ID照合で競合対策済みなら指摘しない。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
query$.pipe(mergeMap(q => api.search(q))).subscribe(v => results.set(v));
```
**改善例（条件付き）**
```typescript
query$.pipe(switchMap(q => api.search(q))).subscribe(v => results.set(v));
```

### NG22-082 [GUIDE] 書き込みAPIでの switchMap の誤用
- **検出条件**: 連続送信で先行リクエストの購読が解除され、処理結果を取り逃すか。
- **誤検知回避**: 最新の送信のみ有効な仕様ならswitchMapが適切な場合がある。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
saveClicks$.pipe(switchMap(v => api.save(v))).subscribe();
```
**改善例（条件付き）**
```typescript
saveClicks$.pipe(exhaustMap(v => api.save(v))).subscribe(); // 二重送信防止の仕様例
```

### NG22-083 [GUIDE] HTTPリトライの冪等性
- **検出条件**: 作成・決済など副作用のあるリクエストを無条件にretryしていないか。
- **誤検知回避**: 冪等キーやサーバー側重複防止がある場合は例外。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
api.createOrder(data).pipe(retry(3)).subscribe();
```
**改善例（条件付き）**
```typescript
api.createOrder(data).subscribe({error: showError}); // 再送は仕様を確認
```

### NG22-084 [SPEC] inject() の実行コンテキスト
- **検出条件**: 通常のイベントハンドラや任意関数内でinject()を呼んでいないか。
- **誤検知回避**: 適切な注入コンテキストで呼ぶ場合は問題なし。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
onClick() { const api = inject(ApiService); api.load(); }
```
**改善例（条件付き）**
```typescript
private readonly api = inject(ApiService); onClick() { this.api.load(); }
```

### NG22-085 [GUIDE] takeUntilDestroyed の注入コンテキスト
- **検出条件**: メソッド内でDestroyRef省略のtakeUntilDestroyed()を呼んでいないか。
- **誤検知回避**: 注入コンテキスト内なら省略可能。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
start() { source$.pipe(takeUntilDestroyed()).subscribe(); }
```
**改善例（条件付き）**
```typescript
private readonly destroyRef = inject(DestroyRef); start() { source$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(); }
```

### NG22-086 [GUIDE] Signalの配列・オブジェクトの破壊的更新
- **検出条件**: signal内の配列を直接pushして通知されると思い込んでいないか。
- **誤検知回避**: 外部の変更検知を明示的に制御する設計なら条件を確認。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
items().push(newItem);
```
**改善例（条件付き）**
```typescript
items.update(old => [...old, newItem]);
```

### NG22-087 [GUIDE] computed と派生状態
- **検出条件**: 計算可能な値をeffectで別signalへ同期し循環・不整合が起きないか。
- **誤検知回避**: 外部I/Oとの同期にはeffectが適切な場合がある。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
effect(() => total.set(price() * count()));
```
**改善例（条件付き）**
```typescript
total = computed(() => price() * count());
```

### NG22-088 [SPEC] 動的HTMLの信頼バイパス
- **検出条件**: 外部入力をbypassSecurityTrustHtmlへ直接渡していないか。
- **誤検知回避**: 固定・検証済みの信頼できるHTMLは要件次第。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
safeHtml = sanitizer.bypassSecurityTrustHtml(userHtml);
```
**改善例（条件付き）**
```typescript
// 通常の[innerHTML]バインディングのAngularサニタイズを利用する（文脈を確認）
```

### NG22-089 [GUIDE] URLパラメータの信頼境界
- **検出条件**: 画面パラメータをAPIの権限判定なしで識別子として使用していないか。
- **誤検知回避**: バックエンド側の所有者検証が確認できれば問題なし。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
// 画面側でidを隠すだけではアクセス制御にならない
```
**改善例（条件付き）**
```typescript
// API側で認証済みユーザーの対象データ権限を検証する
```

### NG22-090 [GUIDE] Reactive Forms の非同期検証
- **検出条件**: 非同期Validatorが適切なObservable/Promiseを返し、完了・エラーを扱うか。
- **誤検知回避**: 同期Validatorのみの場合は対象外。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
const validator = () => api.checkName(name); // 返却型と完了条件が不明
```
**改善例（条件付き）**
```typescript
const validator: AsyncValidatorFn = control => api.checkName(control.value).pipe(map(taken => taken ? {taken:true} : null));
```

### NG22-091 [GUIDE] フォーム二重送信
- **検出条件**: 送信中に複数回の保存が可能で重複作成されないか。
- **誤検知回避**: サーバーの冪等性保証があれば重大度を下げる。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
submit() { this.api.create(this.form.value).subscribe(); }
```
**改善例（条件付き）**
```typescript
submit() { if (this.saving()) return; this.saving.set(true); this.api.create(this.form.value).pipe(finalize(() => this.saving.set(false))).subscribe(); }
```

### NG22-092 [GUIDE] NgRx Reducer の純粋性
- **検出条件**: Reducer内部でHTTP通信・乱数・時刻取得・入力の破壊的変更をしていないか。
- **誤検知回避**: EffectやService内の副作用は対象外。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
on(add, (state, {item}) => { state.items.push(item); return state; })
```
**改善例（条件付き）**
```typescript
on(add, (state, {item}) => ({...state, items: [...state.items, item]}))
```

### NG22-093 [GUIDE] NgRx Effect のエラー継続
- **検出条件**: 外側ストリームがエラー終了し後続Actionを処理できなくならないか。
- **誤検知回避**: 共通の再購読や別レイヤーでエラー回復済みなら除外。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
actions$.pipe(ofType(load), switchMap(() => api.load()), map(loadSuccess))
```
**改善例（条件付き）**
```typescript
actions$.pipe(ofType(load), switchMap(() => api.load().pipe(map(loadSuccess), catchError(error => of(loadFailure({error}))))))
```

### NG22-094 [GUIDE] Guardの戻り値と遷移
- **検出条件**: 認証未完了時の遷移やループを防げるか。
- **誤検知回避**: Guardの存在自体をセキュリティ境界とみなさない。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
return false; // ログイン誘導が別にないと利用者が行き詰まる場合
```
**改善例（条件付き）**
```typescript
return router.createUrlTree(['/login']); // 要件に応じた誘導例
```

### NG22-095 [GUIDE] コンポーネントの非同期後処理
- **検出条件**: コンポーネント破棄後の非同期完了で状態更新・画面遷移しないか。
- **誤検知回避**: 短命処理で破棄後の副作用が無害な場合は優先度を下げる。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
source$.subscribe(value => this.value.set(value));
```
**改善例（条件付き）**
```typescript
source$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(value => this.value.set(value));
```

### NG22-096 [GUIDE] SSR・ブラウザAPIの利用条件
- **検出条件**: SSRを使う構成でwindow/document/localStorageを無条件参照していないか。
- **誤検知回避**: ブラウザ専用SPAならSSR固有の指摘はしない。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
const value = localStorage.getItem('key');
```
**改善例（条件付き）**
```typescript
if (isPlatformBrowser(platformId)) { const value = localStorage.getItem('key'); }
```

### NG22-097 [GUIDE] アクセシブルなフォームエラー
- **検出条件**: 入力エラーが視覚表示だけで、ラベルや支援技術に伝わらないか。
- **誤検知回避**: コンポーネントライブラリが対応済みなら重複指摘しない。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
<input [formControl]="name"><span>必須</span>
```
**改善例（条件付き）**
```typescript
<label for="name">名前</label><input id="name" [formControl]="name" aria-describedby="name-error"><span id="name-error">必須</span>
```

### NG22-098 [GUIDE] @defer と依存性・UX
- **検出条件**: 遅延表示した機能が初期操作に必要なのにプレースホルダーが不十分でないか。
- **誤検知回避**: 初期表示不要な機能なら遅延ロードは適切。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
@defer (on interaction) { <critical-form /> }
```
**改善例（条件付き）**
```typescript
@defer (on viewport) { <optional-chart /> } @placeholder { <p>読み込み前</p> }
```

### NG22-099 [PROJECT] API層分離とNgRxの採用規約
- **検出条件**: プロジェクトで明示された場合のみ、コンポーネントの直接HTTP呼出し等を確認する。
- **誤検知回避**: 公式Angularの必須制約と混同しない。
- **判断方法**: Git差分の該当行と関連する状態・入力経路を示す。見えない実装は「要確認」。

**問題になり得る例**
```typescript
// PROJECT規約例: Component -> HttpClient
```
**改善例（条件付き）**
```typescript
// PROJECT規約例: Component -> Store/Service -> API Service
```

